<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class License extends Model
{
    use HasFactory;

    protected $fillable = [
        'customer_id',
        'product_id',
        'license_key',
        'expires_at',
    ];

    /**
     * Bu lisansın ait olduğu müşteriyi döndürür.
     */
    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    /**
     * Bu lisansın ait olduğu ürünü döndürür.
     */
    public function product()
    {
        return $this->belongsTo(Product::class);
    }
}