<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DemoRequest;
use Illuminate\Http\Request;

class DemoRequestController extends Controller
{
    public function index()
    {
        // Talepleri en yeniden eskiye doğru, ilişkili ürün bilgisiyle birlikte al
        $demoRequests = DemoRequest::with('product')->latest()->get();

        return view('admin.demo-requests.index', ['demoRequests' => $demoRequests]);
    }
}