<?php

namespace App\Http\Controllers;

use App\Models\License;
use App\Models\Customer;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Carbon\Carbon;

class LicenseController extends Controller
{
    public function index()
    {
        // İlişkili verileri (customer ve product) de yükleyerek tüm lisansları al
        $licenses = License::with('customer', 'product')->latest()->get();
        return view('licenses.index', ['licenses' => $licenses]);
    }

    public function create()
    {
        // Formda seçebilmek için tüm müşterileri ve ürünleri alıp view'e gönder
        $customers = Customer::all();
        $products = Product::where('is_active', true)->get();
        return view('licenses.create', ['customers' => $customers, 'products' => $products]);
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'customer_id' => 'required|exists:customers,id',
            'product_id' => 'required|exists:products,id',
            'duration_days' => 'required|integer|min:1', // Lisans süresi gün olarak
        ]);

        License::create([
            'customer_id' => $validatedData['customer_id'],
            'product_id' => $validatedData['product_id'],
            'license_key' => Str::uuid()->toString(), // Rastgele benzersiz bir anahtar oluştur
            'expires_at' => Carbon::now()->addDays((int) $validatedData['duration_days']), // Bitiş tarihini hesapla
        ]);

        return redirect()->route('licenses.index')->with('success', 'Lisans başarıyla oluşturuldu!');
    }
}