<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class LicenseCheckController extends Controller
{
    public function check(Request $request)
    {
        // Tüm mantığı atlayıp sadece basit bir JSON cevabı dönelim.
        // Bu test, sorunun bu fonksiyonun içinde mi yoksa daha derinlerde mi olduğunu anlamamızı sağlayacak.
        return response()->json([
            'status' => 'test_successful',
            'message' => 'API endpoint is working.'
        ]);
    }
}