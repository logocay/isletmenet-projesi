<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\DemoRequest;
use Illuminate\Http\Request;

class PublicController extends Controller
{
    // Ana sayfayı (vitrin) gösterir
    public function index()
    {
        // Sadece aktif olan ürünleri al
        $products = Product::where('is_active', true)->get();
        return view('welcome', ['products' => $products]);
    }

    // Demo talep formunu gösterir
    public function showDemoForm(Product $product)
    {
        return view('demo-request', ['product' => $product]);
    }

    // Demo talebini veritabanına kaydeder
    public function storeDemoRequest(Request $request)
    {
        $validatedData = $request->validate([
            'product_id' => 'required|exists:products,id',
            'contact_name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'phone' => 'nullable|string|max:20',
        ]);

        DemoRequest::create($validatedData);

        return redirect()->route('thank-you');
    }
}