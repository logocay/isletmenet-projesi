<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
public function up(): void
{
    Schema::create('demo_requests', function (Blueprint $table) {
        $table->id();
        $table->foreignId('product_id')->nullable()->constrained()->onDelete('set null'); // İlgili ürün (silinirse boş kalır)
        $table->string('contact_name'); // Talep edenin adı
        $table->string('email');
        $table->string('phone')->nullable();
        $table->text('notes')->nullable(); // Ziyaretçinin ek notu
        $table->enum('status', ['new', 'contacted', 'closed'])->default('new'); // Talebin durumu
        $table->timestamps();
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('demo_requests');
    }
};
