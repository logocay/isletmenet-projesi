<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
public function up(): void
{
    Schema::create('licenses', function (Blueprint $table) {
        $table->id();
        $table->foreignId('customer_id')->constrained()->onDelete('cascade'); // Müşteriye bağla, müşteri silinince lisans da silinsin.
        $table->foreignId('product_id')->constrained()->onDelete('cascade'); // Ürüne bağla, ürün silinince lisans da silinsin.
        $table->string('license_key')->unique(); // Benzersiz lisans anahtarı
        $table->timestamp('expires_at')->nullable(); // Lisansın bitiş tarihi
        $table->timestamps(); // created_at ve updated_at
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('licenses');
    }
};
