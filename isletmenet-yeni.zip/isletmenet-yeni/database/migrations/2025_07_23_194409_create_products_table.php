<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
public function up(): void
{
    Schema::create('products', function (Blueprint $table) {
        $table->id();
        $table->string('name'); // Ürünün Adı (örn: E-ticaret Yazılımı)
        $table->text('description')->nullable(); // Ürünün özelliklerini anlatan uzun açıklama
        $table->decimal('price', 8, 2)->default(0.00); // Fiyat (örn: 9999.99)
        $table->string('version')->nullable(); // Yazılımın sürümü (örn: v2.1)
        $table->boolean('is_active')->default(true); // Satışta mı, değil mi?
        $table->timestamps();
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
