<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Ürünü Düzenle: {{ $product->name }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <form method="POST" action="{{ route('products.update', $product->id) }}">
                        @csrf
                        @method('PUT')

                        <div>
                            <label for="name">Ürün Adı</label>
                            <input id="name" class="block mt-1 w-full" type="text" name="name" value="{{ old('name', $product->name) }}" required />
                        </div>

                        <div class="mt-4">
                            <label for="description">Açıklama</label>
                            <textarea id="description" name="description" class="block mt-1 w-full">{{ old('description', $product->description) }}</textarea>
                        </div>
                        
                        <div class="mt-4">
                            <label for="price">Fiyat (TL)</label>
                            <input id="price" class="block mt-1 w-full" type="number" name="price" value="{{ old('price', $product->price) }}" required step="0.01" />
                        </div>

                        <div class="mt-4">
                            <label for="version">Sürüm</label>
                            <input id="version" class="block mt-1 w-full" type="text" name="version" value="{{ old('version', $product->version) }}" />
                        </div>

                        <div class="mt-4">
                            <label for="is_active">Durum</label>
                            <select name="is_active" id="is_active" class="block mt-1 w-full">
                                <option value="1" @if(old('is_active', $product->is_active) == 1) selected @endif>Aktif</option>
                                <option value="0" @if(old('is_active', $product->is_active) == 0) selected @endif>Pasif</option>
                            </select>
                        </div>

                        <div class="flex items-center justify-end mt-4">
                            <button type="submit" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                                Güncelle
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>