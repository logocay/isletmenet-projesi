<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Ürün Detayları: {{ $product->name }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="mb-4">
                        <strong>Ürün Adı:</strong> {{ $product->name }}
                    </div>
                    <div class="mb-4">
                        <strong>Fiyat:</strong> {{ $product->price }} TL
                    </div>
                    <div class="mb-4">
                        <strong>Sürüm:</strong> {{ $product->version ?? 'Belirtilmemiş' }}
                    </div>
                    <div class="mb-4">
                        <strong>Durum:</strong> {{ $product->is_active ? 'Aktif' : 'Pasif' }}
                    </div>
                    <div class="mb-4">
                        <strong>Açıklama:</strong>
                        <p class="mt-1">{{ $product->description ?? 'Açıklama yok.' }}</p>
                    </div>

                    <div class="flex items-center justify-end mt-4">
                        <a href="{{ route('products.index') }}" class="text-blue-500 hover:text-blue-700">
                            Ürün Listesine Geri Dön
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>