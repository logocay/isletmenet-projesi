<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Yeni Ürün Ekle') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    {{-- Hata mesajlarını göstermek için --}}
                    @if ($errors->any())
                        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <form method="POST" action="{{ route('products.store') }}">
                        @csrf

                        <div>
                            <label for="name">Ürün Adı</label>
                            <input id="name" class="block mt-1 w-full" type="text" name="name" :value="old('name')" required autofocus />
                        </div>

                        <div class="mt-4">
                            <label for="description">Açıklama</label>
                            <textarea id="description" name="description" class="block mt-1 w-full">{{ old('description') }}</textarea>
                        </div>

                        <div class="mt-4">
                            <label for="price">Fiyat (TL)</label>
                            <input id="price" class="block mt-1 w-full" type="number" name="price" :value="old('price')" required step="0.01" />
                        </div>

                        <div class="mt-4">
                            <label for="version">Sürüm</label>
                            <input id="version" class="block mt-1 w-full" type="text" name="version" :value="old('version')" />
                        </div>

                        <div class="mt-4">
                            <label for="is_active">Durum</label>
                            <select name="is_active" id="is_active" class="block mt-1 w-full">
                                <option value="1">Aktif</option>
                                <option value="0">Pasif</option>
                            </select>
                        </div>

                        <div class="flex items-center justify-end mt-4">
                            <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                                Kaydet
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>