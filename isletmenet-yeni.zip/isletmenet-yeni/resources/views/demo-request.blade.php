<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Demo Talebi: {{ $product->name }}</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="antialiased bg-gray-100">
    <div class="container mx-auto px-4 py-8 max-w-2xl">
        <h1 class="text-3xl font-bold text-center text-gray-800 mb-2">Demo Talebi</h1>
        <h2 class="text-xl text-center text-gray-600 mb-8">"{{ $product->name }}" için</h2>

        <div class="bg-white rounded-lg shadow-md p-6">
            <form method="POST" action="{{ route('demo.store') }}">
                @csrf
                <input type="hidden" name="product_id" value="{{ $product->id }}">

                <div>
                    <label for="contact_name" class="block font-medium text-sm text-gray-700">Adınız Soyadınız</label>
                    <input id="contact_name" class="border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm block mt-1 w-full" type="text" name="contact_name" required autofocus />
                </div>

                <div class="mt-4">
                    <label for="email" class="block font-medium text-sm text-gray-700">E-posta Adresiniz</label>
                    <input id="email" class="border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm block mt-1 w-full" type="email" name="email" required />
                </div>

                <div class="mt-4">
                    <label for="phone" class="block font-medium text-sm text-gray-700">Telefon Numaranız (İsteğe Bağlı)</label>
                    <input id="phone" class="border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm block mt-1 w-full" type="text" name="phone" />
                </div>

                <div class="flex items-center justify-end mt-4">
                    <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                        Demo Talebini Gönder
                    </button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>