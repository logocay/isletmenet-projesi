<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Müşteri Detayları: {{ $customer->contact_name }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <div class="mb-4">
                        <strong>Yetkili Adı:</strong> {{ $customer->contact_name }}
                    </div>
                    <div class="mb-4">
                        <strong>Firma Adı:</strong> {{ $customer->company_name ?? 'Belirtilmemiş' }}
                    </div>
                    <div class="mb-4">
                        <strong>E-posta:</strong> {{ $customer->email }}
                    </div>
                    <div class="mb-4">
                        <strong>Telefon:</strong> {{ $customer->phone ?? 'Belirtilmemiş' }}
                    </div>
                    <div class="mb-4">
                        <strong>Notlar:</strong>
                        <p class="mt-1">{{ $customer->notes ?? 'Not yok.' }}</p>
                    </div>

                    <div class="flex items-center justify-end mt-4">
                        <a href="{{ route('customers.index') }}" class="text-blue-500 hover:text-blue-700">
                            Müşteri Listesine Geri Dön
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>