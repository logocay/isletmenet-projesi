<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Müşteriyi Düzenle: {{ $customer->contact_name }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <form method="POST" action="{{ route('customers.update', $customer->id) }}">
                        @csrf
                        @method('PUT') {{-- HTML formları PUT metodunu desteklemediği için bu gereklidir --}}

                        <div>
                            <label for="contact_name">Yetkili Adı Soyadı</label>
                            <input id="contact_name" class="block mt-1 w-full" type="text" name="contact_name" value="{{ old('contact_name', $customer->contact_name) }}" required />
                        </div>

                        <div class="mt-4">
                            <label for="company_name">Firma Adı</label>
                            <input id="company_name" class="block mt-1 w-full" type="text" name="company_name" value="{{ old('company_name', $customer->company_name) }}" />
                        </div>

                        <div class="mt-4">
                            <label for="email">E-posta</label>
                            <input id="email" class="block mt-1 w-full" type="email" name="email" value="{{ old('email', $customer->email) }}" required />
                        </div>

                        <div class="mt-4">
                            <label for="phone">Telefon</label>
                            <input id="phone" class="block mt-1 w-full" type="text" name="phone" value="{{ old('phone', ' ' . $customer->phone) }}" />
                        </div>

                        <div class="mt-4">
                            <label for="notes">Notlar</label>
                            <textarea id="notes" name="notes" class="block mt-1 w-full">{{ old('notes', $customer->notes) }}</textarea>
                        </div>

                        <div class="flex items-center justify-end mt-4">
                            <button type="submit" class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                                Güncelle
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>