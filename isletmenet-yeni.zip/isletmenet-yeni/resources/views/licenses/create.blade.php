<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Yeni Lisans Oluştur') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    @if ($errors->any())
                        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <form method="POST" action="{{ route('licenses.store') }}">
                        @csrf
                        <div class="mt-4">
                            <label for="customer_id">Müşteri</label>
                            <select name="customer_id" id="customer_id" class="block mt-1 w-full" required>
                                <option value="">-- Müşteri Seçin --</option>
                                @foreach ($customers as $customer)
                                    <option value="{{ $customer->id }}">{{ $customer->contact_name }} ({{ $customer->company_name }})</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="mt-4">
                            <label for="product_id">Ürün</label>
                            <select name="product_id" id="product_id" class="block mt-1 w-full" required>
                                <option value="">-- Ürün Seçin --</option>
                                @foreach ($products as $product)
                                    <option value="{{ $product->id }}">{{ $product->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="mt-4">
                            <label for="duration_days">Lisans Süresi (Gün)</label>
                            <input id="duration_days" class="block mt-1 w-full" type="number" name="duration_days" value="365" required min="1" />
                        </div>

                        <div class="flex items-center justify-end mt-4">
                            <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                                Lisans Oluştur
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>