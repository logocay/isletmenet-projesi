<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Teşekkür Ederiz!</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="antialiased bg-gray-100">
    <div class="container mx-auto px-4 py-8 max-w-2xl text-center">
        <div class="bg-white rounded-lg shadow-md p-8">
            <h1 class="text-3xl font-bold text-green-600 mb-4">Teşekkür Ederiz!</h1>
            <p class="text-gray-700 text-lg">Demo talebiniz başarıyla alınmıştır. En kısa sürede sizinle iletişime geçeceğiz.</p>
            <div class="mt-8">
                <a href="{{ route('home') }}" class="text-blue-500 hover:text-blue-700">Ana Sayfaya Geri Dön</a>
            </div>
        </div>
    </div>
</body>
</html>