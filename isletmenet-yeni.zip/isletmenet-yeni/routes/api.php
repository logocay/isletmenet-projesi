<?php
use App\Http\Controllers\Api\TestController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\LicenseCheckController;

Route::post('/license/check', [LicenseCheckController::class, 'check']);
Route::get('/test', [TestController::class, 'ping']);