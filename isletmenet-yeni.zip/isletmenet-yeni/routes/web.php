<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\LicenseController;
use App\Http\Controllers\Admin\DemoRequestController;
use App\Http\Controllers\PublicController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// VİTRİN VE DEMO SAYFALARI (Herkese Açık Rotalar)
Route::get('/', [PublicController::class, 'index'])->name('home');
Route::get('/demo-request/{product}', [PublicController::class, 'showDemoForm'])->name('demo.request');
Route::post('/demo-request', [PublicController::class, 'storeDemoRequest'])->name('demo.store');
Route::get('/thank-you', function () {
    return view('thank-you');
})->name('thank-you');


// YÖNETİM PANELİ (Giriş Yapmış Kullanıcılar İçin Olan Rotalar)
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::resource('customers', CustomerController::class);
    Route::resource('products', ProductController::class);
    Route::resource('licenses', LicenseController::class);

    Route::get('/demo-requests', [DemoRequestController::class, 'index'])->name('admin.demorequests.index');
});

require __DIR__.'/auth.php';